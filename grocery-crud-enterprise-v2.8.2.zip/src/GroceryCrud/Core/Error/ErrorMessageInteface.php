<?php
namespace GroceryCrud\Core\Error;

interface ErrorMessageInteface {

    /**
     * @return string
     */
    public function getMessage();
}