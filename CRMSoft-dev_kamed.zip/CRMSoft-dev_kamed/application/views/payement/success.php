<!-- /#Header -->
<?php
require_once(APPPATH . "views/templates/header.php");
?>
<?php include(APPPATH . "views/templates/header_main.php"); ?>
<!--heder end here-->
<!--inner block start here-->

  <div class="chit-chat-layer1">
    <div class="col-md-12">
  <div class="chit-chat-heading">
Ouverture de dossier &nbsp;
</div>

<br/>
<br/>
<br/>
<br/>
<br/>

<h2 class="bg-success" style="text-align:center">PAYEMENT ENREGISTRE AVEC SUCCES !</h2>
<br/>
<br/><br/>
<br/>
<h4 class="text-primary" style="text-align:center"><a href="<?php echo site_url('payement/')?>">Allez aux payements !</a></h4>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>

<?php include(APPPATH . "views/templates/footer.php"); ?>
